/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Device Manager
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger'],
function(Logger) {

	var DeviceType = {
		Chrome: 'Chrome',
		iOS: 'iOS',
		Android: 'Android'
	};

	var init = function() {

	};

	var getType = function() {
		if (navigator.userAgent.toLowerCase().match(/android/)) {
			return DeviceType.Android;
		} else if (navigator.userAgent.toLowerCase().match(/iphone/) || navigator.userAgent.toLowerCase().match(/ipad/)) {
			return DeviceType.iOS;
		} else {
			return DeviceType.Chrome;
		}
	};

	return {
		init: init,
		getType: getType
	};
});