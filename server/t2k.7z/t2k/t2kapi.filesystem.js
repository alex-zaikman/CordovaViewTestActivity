/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* File system Manager
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.device', './t2kapi.logger'],
function(Device, Logger) {

	var _fs;
	var _dirs = [];
	var size = 500 * 1024 * 1024;
	var _index_file_entry = null;
	var _handlers = {
		quotaExceeded: function(){}
	};

	var Error = {
		QuotaExceeded: "QuotaExceeded",
		Unknown: 'Unknown'
	};

	var fs_error = function(err) {
		if (typeof(err) === 'object') {
			if (FileError && err.code === FileError.QUOTA_EXCEEDED_ERR) {
				_handlers.quotaExceeded();
				return Error.QuotaExceeded;
			} else {
				return Error.Unknown;
			}
		} else {
			return Error.Unknown;
		}
	};

	var init = function(params) {
		var PERSISTENT = (typeof(LocalFileSystem) !== 'undefined') ? LocalFileSystem.PERSISTENT : window.PERSISTENT;
		var requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
		_handlers.quotaExceeded = params.quotaExceeded || _handlers.quotaExceeded;
		if (Device.getType() === 'Chrome') {
			window.webkitStorageInfo.requestQuota(PERSISTENT, size, function(){
				requestFileSystem(PERSISTENT, size, function(fs){
					_fs = fs;
					params.success(true);
				}, params.error);
			}, params.error);
		} else {
			requestFileSystem(PERSISTENT, size, function(fs){
				_fs = fs;
				params.success(true);
			}, params.error);
		}
	};

	var createResource = function(url, data) {
		var val,key,rx;
		if (data) {
			for (key in data) {
				val = data[key];
				rx = new RegExp(":"+key,'g');
				url = url.replace(rx,val);
			}
		}
		return url;
	};

	var encodeResource = function(resource) {
		var encoded = resource.replace(/^(https?:\/\/)?[^/]+\.[^/]+(\.[^/]+)?(:\d+)?/,"");	
		encoded = encoded.replace(/^https?:\/\/[^/]+/,"");
		encoded = encoded.replace(/\//g, "_");
		return encoded;
	};

	var createNestedDirectory = function(path, success, error) {
		var dirs = path.split('/');
		for (var i = 1; i < dirs.length; i++) {
			var subdir = dirs.slice(0, i+1).join('/');
			if (_dirs.indexOf(subdir) === -1) {
				_fs.root.getDirectory(subdir, {create: true}, function() {
					_dirs.push(subdir);
					createNestedDirectory(path, success, error);
				}, error);
				return;
			}
		}
		success();
	};

	var save = function(path, params, options) {
		options = options || {};
		options.success = options.success || function(){};
		options.error = options.error || function(){};
		path = createResource(path, params);
		Logger.d('fs', 'saving file at: $$', path);
		var dirname = path.match(/.*\//)[0].replace(/\/$/,'');
		createNestedDirectory(dirname, function(){
			_fs.root.getFile(path, {create: true}, function(fileEntry){
				var blob = (options.type) ? new Blob([params.data], {type: options.type}) : new Blob([params.data]);
				fileEntry.createWriter(function(writer){
					writer.onerror = function(err){ options.error(fs_error(err));};
					writer.onwriteend = function(){
						options.success(path);
					};
					writer.write(blob);
				}, options.error);
			},options.error);
		}, options.error);
	};

	var exists = function(path, params, options) {
		options = options || {};
		options.success = options.success || function(){};
		options.error = options.error || function(){};
		path = createResource(path, params);
		_fs.root.getFile(path, {create: false}, options.success, options.error);
	};

	var download = function(url, path, params, options) {
		options = options || {};
		options.success = options.success || function(){};
		options.error = options.error || function(){};
		path = createResource(path, params);
		url = createResource(url, params);
		var dirname = path.match(/.*\//)[0].replace(/\/$/,'');
		var fileTransfer = new FileTransfer();
		createNestedDirectory(dirname, function(){
			fileTransfer.download(
				url,
				_fs.root.fullPath + path,
				function(){ options.success(path);},
				function(err){ options.error(fs_error(err));}
			);
		}, options.error);
		return { abort: fileTransfer.abort };
	};

	var getBasePath = function() {
		return _fs.root.fullPath;
	};

	var removeDirectory = function(path, params, options) {
		options = options || {};
		options.success = options.success || function(){};
		options.error = options.error || function(){};
		path = createResource(path, params);
		_fs.root.getDirectory(path, function(entry){
			entry.removeRecursively(options.success, options.error);
		}, options.error);
	};

	return {
		init: init,
		save: save,
		exists: exists,
		download: download,
		getBasePath: getBasePath,
		removeDirectory: removeDirectory
	};
});
