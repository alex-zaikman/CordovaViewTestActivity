/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Iterator
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(function() {
	
	return {

		Lesson: {
			each: function(root, callback) {
				var i;
				for (var key in root) {
					if (key === 'tocItems') {
						for (i = 0; i < root[key].length; i++) {
							this.each(root[key][i], callback);
						}
					} else if (key === 'items') {
						for (i = 0; i < root[key].length; i++) {
							if (root[key][i].type === 'lesson') {
								callback(root[key][i]);
							}
						}
					}
				}
			}
		},

		Sequence: {
			each: function(root, callback) {
				var i;
				for (var key in root) {
					if ((key === 'learningObjects') || (key === 'learningActivities')){
						for (i = 0; i < root[key].length; i++) {
							this.each(root[key][i], callback);
						}
					} else if (key === 'sequences') {
						for (i = 0; i < root[key].length; i++) {
							if (root[key][i].levels) {
								for (var j = 0; j < root[key][i].levels.length; j++) {
									var ret = callback(root[key][i].levels[j].sequence);
									if (ret) {
										root[key][i].levels[j].sequence = ret;
									}
								}
							}
							var ret = callback(root[key][i]);
							if (ret) {
								root[key][i] = ret;
							}
						}
					}
				}
			}
		},

		Standard: {
			each: function(root, callback) {
				callback(root);
				if (root.children) {
					for (var i = 0; i < root.children.length; i++) {
						this.each(root.children[i], callback);
					}
				}
			}
		},

		Assessment: {
			each: function(root, callback) {
				var i;
				for (var key in root) {
					if (key === 'tocItems') {
						var founded;
						for (i = 0; i < root[key].length; i++) {
							this.each(root[key][i], callback);
						}
					} else if (key === 'items') {
						for (i = 0; i < root[key].length; i++) {
							if (root[key][i].type === 'assessment') {
								callback(root[key][i]);
							}
						}
					}
				}
			}
		}
	};

});