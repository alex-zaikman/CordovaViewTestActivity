/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Course Downloader Manager
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.model', './t2kapi.filesystem', './t2kapi.server', './t2kapi.db', './t2kapi.device', './t2kapi.logger'],
function(Model, FS, Server, DB, Device, Logger) {

	var _downloader_state_table = "general";
	var _downloader_state_key = "downloader-states";
	var _base_dir = "/midtier/downloads";
	var _download_list = {};
	var _downloading = false;
	var _keep_downloading = true;
	var _downloading_stopped_callback;
	var _download_delay = 0;

	var DownloadState = {
		Started: 'Started',
		Progress: 'Progress',
		Ended: 'Ended',
		Error: 'Error'
	};

	var DownloadDelay = {
		High: 0,
		Low: 200
	};

	var _handlers = {
		courseStart: function(object){},
		courseProgress: function(object){},
		itemProgress: function(object){},
		courseSuccess: function(object){},
		itemSuccess: function(object){},
		courseError: function(object){},
		itemError: function(object){}
	};

	var init = function(options) {
		_handlers.courseStart = options.courseStart;
		_handlers.courseProgress = options.courseProgress;
		_handlers.itemProgress = options.itemProgress;
		_handlers.courseSuccess = options.courseSuccess;
		_handlers.itemSuccess = options.itemSuccess;
		_handlers.courseError = options.courseError;
		_handlers.itemError = options.itemError;
		Server.onChangeState(onServerChangeState);
		loadDownloaderState();
	};

	var start = function() {
		downloadNextCourse();
	};

	var onServerChangeState = function(online) {
		if (online && _downloading === false) {
			Logger.d("downloader", "back from offline, resuming download...");
			downloadNextCourse();
		}
	};

	var saveDownloaderState = function(callback) {
		DB.save(_downloader_state_table, {name: _downloader_state_key, data: _download_list}, {
			success: callback,
			error: callback
		});
	};

	var loadDownloaderState = function(callback) {
		callback = callback || function(){};
		DB.get(_downloader_state_table, {name: _downloader_state_key}, {
			success: function(items) {
				if (items && items.length) {
					_download_list = items[0].data;
				}
				callback();
			},
			error: function() {
				callback();
			}
		});
	};

	var storeItemAsset = function(courseCid, asset, response, success, error) {
		FS.save(_base_dir + '/courses/:courseCid/:asset', {courseCid: courseCid, asset: asset, data: response}, {
			type: (asset.indexOf('.json') !== -1) ? 'text/plain' : null,
			success: success,
			error: error
		});
	};

	var downloadItemAssets = function(courseId, courseCid, itemType, itemCid, assets, totalAssets, options) {
		if (!_keep_downloading) {
			_downloading = false;
			if (_downloading_stopped_callback) {
				_downloading_stopped_callback();
			}
			return;
		}
		if (assets.length) {
			var params = { courseCid: courseCid, asset: assets.pop()};
			FS.exists(_base_dir + '/courses/:courseCid/:asset', params, {
				success: function(){
					_download_list[courseId][itemType][itemCid].progress = ((totalAssets - assets.length) / totalAssets) * 100;
					_handlers.itemProgress(courseId, itemCid, _download_list[courseId][itemType][itemCid].progress);
					setTimeout(function(){
						downloadItemAssets(courseId, courseCid, itemType, itemCid, assets, totalAssets, options);
					},_download_delay);
				},
				error: function() {
					Logger.d("downloader", "getting asset from server: $$", params.asset);
					if (Device.getType() === 'Chrome') {
						Server.getAsset('/cms/courses/:courseCid/:asset', params, {
							success: function(response, originalUri) {
								storeItemAsset(courseCid, params.asset, response, function(assetUri) {
									_download_list[courseId][itemType][itemCid].progress = ((totalAssets - assets.length) / totalAssets) * 100;
									_handlers.itemProgress(courseId, itemCid, _download_list[courseId][itemType][itemCid].progress);
									setTimeout(function(){
										downloadItemAssets(courseId, courseCid, itemType, itemCid, assets, totalAssets, options);
									},_download_delay);
								}, options.error);
							},
							error: function(){
								Server.isOnline(function(online){
									if (online) {
										options.error();
									} else {
										options.offline();
									}
								});
							}
						});
					} else {
						FS.download(window.location.origin + '/cms/courses/:courseCid/:asset',
									_base_dir + '/courses/:courseCid/:asset', params, {
							success: function() {
								_download_list[courseId][itemType][itemCid].progress = ((totalAssets - assets.length) / totalAssets) * 100;
								_handlers.itemProgress(courseId, itemCid, _download_list[courseId][itemType][itemCid].progress);
								setTimeout(function(){
									downloadItemAssets(courseId, courseCid, itemType, itemCid, assets, totalAssets, options);
								},_download_delay);
							},
							error: function(err){
								if (err === 'Unknown') {
									Server.isOnline(function(online){
										if (online) {
											options.error(err);
										} else {
											options.offline();
										}
									});
								} else {
									error(err);
								}
							}
						});
					}
				}
			});
		} else {
			options.success();
		}
	};

	var downloadNextItem = function(courseList, courseId, courseCid, totalItems, downloadedItems, priorityOptions) {
		var prefetchUrl = 'rest/userlibrary/courses/:courseId/:type/:cid/prefetchlist';
		var itemCid = null;
		var itemType = null;
		var modelName = null;
		var params = null;

		if (!(priorityOptions && priorityOptions.isAssessment)) {
			for (var cid in courseList.lessons) {
				if (courseList.lessons[cid].state !== DownloadState.Ended) {
					itemCid = cid;
					itemType = "lessons";
					modelName = "lessonContent";
					params = {courseId: courseId, lessonCid: itemCid};
					break;
				}
			}
		}
		if (itemCid === null) {
			for (var cid in courseList.assessments) {
				if (courseList.assessments[cid].state !== DownloadState.Ended) {
					itemCid = cid;
					itemType = "assessments";
					modelName = "assessment";
					params = {courseId: courseId, assessmentCid: itemCid};
					break;
				}
			}
		}
		if (itemCid === null) {
			return courseDownloadSuccessHandler(courseId);
		}

		Logger.d('downloader',"downloading item cid: $$, type: $$", itemCid, itemType);

		Model(modelName).where(params).get(function(itemData){
			Server.get(prefetchUrl, { courseId: courseId, type: itemType, cid: itemCid}, {
				success: function(response) {
					Logger.d('downloader',"item cid: $$ prefetch list is received", itemCid);
					_download_list[courseId][itemType][itemCid].state = DownloadState.Progress;
					var assets = response.assets || [];
					downloadItemAssets(courseId, courseCid, itemType, itemCid, assets.reverse(), assets.length, {
						success: function(){
							_download_list[courseId][itemType][itemCid].state = DownloadState.Ended;
							_download_list[courseId][itemType][itemCid].progress = 100;
							_handlers.itemProgress(courseId, itemCid, _download_list[courseId][itemType][itemCid].progress);
							_handlers.itemSuccess(courseId, itemCid);
							_download_list[courseId].progress = (++downloadedItems/totalItems) * 100;
							_handlers.courseProgress(courseId, _download_list[courseId].progress);
							_download_delay = DownloadDelay.Low;
							saveDownloaderState();
							downloadNextItem(_download_list[courseId], courseId, courseCid, totalItems, downloadedItems);
						},
						error: function(err) {
							_download_list[courseId][itemType][itemCid].state = DownloadState.Error;
							courseDownloadErrorHandler(courseId);
						},
						offline: function() {
							courseDownloadOfflineHandler(courseId);
						}
					});
				},
				error: function() {
					_download_list[courseId][itemType][itemCid].state = DownloadState.Error;
					courseDownloadErrorHandler(courseId);
				},
				offline: function() {
					courseDownloadOfflineHandler(courseId);
				}
			});
		});
	};

	var startCourseDownload = function(courseId, priorityOptions) {
		_downloading = true;
		Logger.d('downloader', 'downloading course id: $$', courseId);
		Model('course').where({courseId: courseId}).get(function(courseData) {
			if (courseData) {
				Server.get('rest/userlibrary/courses/:courseId/prefetchlist', {courseId: courseId}, {
					success: function(response) {
						Logger.d('downloader','course id: $$ prefetch list is received', courseId);
						_download_list[courseId].state = DownloadState.Progress;
						var lessonCids = response.lessonCids || [];
						var assessmentCids = response.assessmentCids || [];
						var remainingItemsToDownload = 0;
						if (priorityOptions && priorityOptions.itemCid) {
							if (lessonCids.indexOf(priorityOptions.itemCid) !== -1) {
								lessonCids.splice(lessonCids.indexOf(priorityOptions.itemCid), 1);
								lessonCids.unshift(priorityOptions.itemCid);
							} else if (assessmentCids.indexOf(priorityOptions.itemCid) !== -1) {
								assessmentCids.splice(assessmentCids.indexOf(priorityOptions.itemCid), 1);
								assessmentCids.unshift(priorityOptions.itemCid);
								priorityOptions.isAssessment = true;
							}
						}
						var lessons = {};
						for (var i = 0; i < lessonCids.length; i++) {
							lessons[lessonCids[i]] = (typeof(_download_list[courseId].lessons[lessonCids[i]]) === 'undefined') ?
							{state: DownloadState.Started, progress: 0} : _download_list[courseId].lessons[lessonCids[i]];
							if (lessons[lessonCids[i]].state !== DownloadState.Ended) {
								remainingItemsToDownload++;
							}
						}
						var assessments = {};
						for (var i = 0; i < assessmentCids.length; i++) {
							assessments[assessmentCids[i]] = (typeof(_download_list[courseId].assessments[assessmentCids[i]]) === 'undefined') ?
							{state: DownloadState.Started, progress: 0} : _download_list[courseId].assessments[assessmentCids[i]];
							if (assessments[assessmentCids[i]] !== DownloadState.Ended) {
								remainingItemsToDownload++;
							}
						}
						_download_list[courseId].lessons = lessons;
						_download_list[courseId].assessments = assessments;
						if (priorityOptions) {
							_download_delay = DownloadDelay.High;
						}
						downloadNextItem(_download_list[courseId], courseId, courseData.data.cid, assessmentCids.length + lessonCids.length, assessmentCids.length + lessonCids.length - remainingItemsToDownload, priorityOptions);
					},
					error: function() {
						courseDownloadErrorHandler(courseId);
					},
					offline: function() {
						courseDownloadOfflineHandler(courseId);
					}
				});
			} else {
				courseDownloadOfflineHandler(courseId);
			}
		});
	};

	var courseDownloadOfflineHandler = function(courseId) {
		Logger.d('downloader',"offline mode is detected, stop downloading course: $$", courseId);
		_downloading = false;
	};

	var courseDownloadErrorHandler = function(courseId) {
		Logger.e('downloader',"error is detected, downloader is stopping.", courseId);
		_downloading = false;
		_download_list[courseId].state = DownloadState.Error;
		_handlers.courseError(courseId);
	};

	var courseDownloadSuccessHandler = function(courseId) {
		_downloading = false;
		Logger.d('downloader',"downloading course : $$ is over.", courseId);
		_download_list[courseId].state = DownloadState.Ended;
		_download_list[courseId].progress = 100;
		_handlers.courseProgress(courseId, _download_list[courseId].progress);
		_handlers.courseSuccess(courseId);
		saveDownloaderState();
		downloadNextCourse();
	};

	var getState = function() {
		return _download_list;
	};

	var getAssetUriReplaceObject = function(originalUrl) {
		var regexp = "^.*\/cms\/courses\/";
		var replace = _base_dir + "/courses/";
		switch(Device.getType()) {
			case 'Chrome':
				replace = "filesystem:" + window.location.origin + '/persistent' + replace;
				break;
			case 'Android':
				replace = "/!/filesystem/!/" + FS.getBasePath() + replace;
				break;
			case 'iOS':
				replace = "/!/filesystem/!/" + FS.getBasePath() + replace;
				break;
		}
		return {
			regexp: regexp,
			replace: replace
		};
	};

	var stopDownload = function(callback) {
		_downloading_stopped_callback = callback;
		_keep_downloading = false;
		if (!_downloading) {
			_downloading_stopped_callback();
		}
	};

	var downloadNextCourse = function(priorityOptions) {
		_keep_downloading = true;
		if (priorityOptions) {
			startCourseDownload(priorityOptions.courseId, priorityOptions);
		} else {
			for (var key in _download_list) {
				if (_download_list[key].state !== DownloadState.Ended) {
					startCourseDownload(key);
					return;
				}
			}
		}
	};

	var downloadCourse = function(courseId, priorityOptions) {
		_handlers.courseStart(courseId);
		if (typeof(_download_list[courseId]) === 'undefined') {
			_download_list[courseId] = { state: DownloadState.Started, progress: 0, lessons: {}, assessments: {}};
			_handlers.courseProgress(courseId, 0);
		}
		saveDownloaderState();
		if (!_downloading) {
			downloadNextCourse(priorityOptions);
		}
	};

	var downloadCourseItemNow = function(courseId, itemCid) {
		stopDownload(function(){
			downloadCourse(courseId, {
				courseId: courseId,
				itemCid: itemCid
			});
		});
	};

	var removeCourse = function(courseCid, options) {
		options = options || {};
		options.success = options.success || function(){};
		options.error = options.error || function(){};
		FS.removeDirectory(_base_dir + '/courses/:courseCid', {courseCid: courseCid}, options);
	};

	return {
		init: init,
		start: start,
		downloadCourse: downloadCourse,
		downloadCourseItemNow: downloadCourseItemNow,
		getState: getState,
		getAssetUriReplaceObject: getAssetUriReplaceObject,
		removeCourse: removeCourse
	};
});
