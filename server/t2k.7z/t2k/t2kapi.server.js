/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Server
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger'],
function(Logger) {

	var _server_state = 'ONLINE';
    var _server_domain = window.location.protocol + '//' + document.domain + '/lms/';

	var _config = {
		serverAjaxRetries: 3,
		serverAjaxRetryDelay: 250,
		serverOnlineInterval: 2000,
		serverAjaxTimeout: 15000
	};

	var _change_state_listeners = [];

	var _establishing_connection = false;

	var createResource = function(url, data) {
		var val,key,rx;
		if (data) {
			for (key in data) {
				val = data[key];
				rx = new RegExp(":"+key,'g');
				url = url.replace(rx,val);
			}
		}
		return url;
	};

	var isServerError = function(jqXHR) {
		var serverErrObj;
		if (jqXHR && jqXHR.responseText) {
			try {
				serverErrObj = JSON.parse(jqXHR.responseText);
				if (serverErrObj && (serverErrObj.errorCode || serverErrObj.error)) {
					return true;
				}
			} catch (ex) {
				return false;
			}
		}
		return false;
	};

	var isServerResponse = function(jqXHR) {
		var header = jqXHR.getResponseHeader('T2kSignature');
		return header || isServerError(jqXHR);
	};

	var pingServer = function(callback) {
		$.ajax({
			url: 'ext/ping?midtier',
			type: 'head',
			success: function() {
				callback(true);
			},
			error: function(jqXHR) {
				callback(false);
			}
		});
	};

	var checkOnline = function() {
		var online_check_interval = setInterval(function(){
			pingServer(function(online){
				if (online) {
					clearInterval(online_check_interval);
					updateServerState('ONLINE');
				}
			});
		},_config.serverOnlineInterval);
	};

	var updateServerState = function(newState) {
		if (_server_state !== newState) {
			Logger.d('server', 'server has a new state: $$', newState);
			for (var i = 0; i < _change_state_listeners.length; i++) {
				_change_state_listeners[i].apply(this, [(newState === 'ONLINE')]);
			}
			_server_state = newState;

			if (newState === 'OFFLINE') {
				checkOnline();
			}
		}
	};

	return {

		init: function() {
			$.ajaxSetup({
				timeout: _config.serverAjaxTimeout
			});
		},

		config: function(params) {
			for (var key in params) {
				_config[key] = params[key];
			}
		},

		get: function(url, params, options) {
			var options = options || {},
				success = options.success || function(){},
				context = options.context || this,
				error = options.error || function(){},
				offline = options.offline || function(){},
				crossDomain = options.crossDomain || false,
				xhrFields = options.xhrFields || {},
				async = options.async || true,
				dataType = options.dataType || 'json',
				data = options.data || null,
				forceOffline = options.forceOffline || false;

			url = createResource(url, params);

			Logger.d('server', 'fetching data from server for url', url);

			if (!forceOffline) {
				if ((_server_state === 'OFFLINE') || _establishing_connection) {
					return offline.apply(context, []);
				}
			}
var tmp = url.indexOf('http') == -1 ? _server_domain + url : url ;

			$.ajax({
				url: tmp,
				dataType: dataType,
				data: data,
				retriesCounter: 1,
				crossDomain: crossDomain,
				xhrFields: xhrFields,
				type: 'GET',
				success: function(data) {
					updateServerState('ONLINE');
					Logger.d('server', 'data from server is fetched successfully for url $$, data $$', url, data);
					success.apply(context, [data]);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					if (!isServerResponse(jqXHR) || ((jqXHR.status === 403) || (jqXHR.status === 302))) {
						if (this.retriesCounter === _config.serverAjaxRetries) {
							Logger.d('server', 'server is not reachable, going to offline mode, cant fetch url: $$', url);
							updateServerState('OFFLINE');
							offline.apply(context, []);
						} else {
							this.retriesCounter++;
							var ajaxContext = this;
							setTimeout(function(){
								$.ajax(ajaxContext);
							},_config.serverAjaxRetryDelay);
						}
					} else {
						Logger.e('server', 'server error for url $$', url);
						error(jqXHR, textStatus, errorThrown);
					}
				}
			});
		},

		saveInChunks: function(url, params, options) {
			var options = options || {},
				success = options.success || function(){},
				context = options.context || this,
				offline = options.offline || function(){},
				error = options.error || function(){},
				chunk_success = options.chunk_success || function(){},
				dataArray = params.data,
				itemsInChunk = 10;

			var runChunkSave = function(data, cIndex) {
				this.save(url, {data: data}, {
					success: function(res) {
						Logger.d('server', 'chunk #$$ is sent successfuly', cIndex);
						chunk_success.apply(context, [(cIndex * itemsInChunk), data.length, res]);
					},
					error: error,
					offline: error
				});
			};

			if (dataArray.length) {
				var chunkIndex = 0;
				while (dataArray.length) {
					runChunkSave.apply(this, [dataArray.splice(0, itemsInChunk), chunkIndex++]);
				}
			} else {
				success.apply(context, [[]]);
			}
		},

		put: function(url, params, options) {
			options.type = 'put';
			this.save(url, params, options);
		},

		post: function(url, params, options) {
			options.type = 'post';
			this.save(url, params, options);
		},

		save: function(url, params, options) {
			var options = options || {},
				success = options.success || function(){},
				context = options.context || this,
				offline = options.offline || function(){},
				error = options.error || function(){},
				forceOffline = options.forceOffline || false;
			url = createResource(url, params);

			Logger.d('server', 'post data to server for url $$', url);

			if (!forceOffline) {
				if ((_server_state === 'OFFLINE') || _establishing_connection) {
					return offline.apply(context, []);
				}
			}
var tmp = url.indexOf('http') == -1 ? _server_domain + url : url ;

			$.ajax({
				url: tmp,
				dataType: 'json',
				type: options.type || 'put',
				contentType: "application/json",
				data: JSON.stringify(params.data),
				retriesCounter: 1,
				success: function(data){
					Logger.d('server', 'successfully posting data to server for url $$', url);
					updateServerState('ONLINE');
					success.apply(context, [data]);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					if (!isServerResponse(jqXHR) || ((jqXHR.status === 403) || (jqXHR.status === 302))) {
						if (this.retriesCounter === _config.serverAjaxRetries) {
							Logger.d('server', 'server is not reachable, going to offline mode, cant save url: $$', url);
							updateServerState('OFFLINE');
							offline.apply(context, []);
						} else {
							this.retriesCounter++;
							var ajaxContext = this;
							setTimeout(function(){
								$.ajax(ajaxContext);
							},_config.serverAjaxRetryDelay);
						}
					} else {
						Logger.d('server', 'server error for url $$', url);
						error(jqXHR, textStatus, errorThrown);
					}
				}
			});
		},

		isOnline: function(callback) {
			pingServer(callback);
		},

		onChangeState: function(listener) {
			_change_state_listeners.push(listener);
		},

		establishingConnection: function(establishing_connection) {
			_establishing_connection = establishing_connection;
		}
	};
});