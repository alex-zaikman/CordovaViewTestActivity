/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Models
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger', './t2kapi.server', './t2kapi.db'],
function(Logger, Server, DB) {

	var Policy = {
		Never: 1,
		Always: 2, // (default)
		FirstTime: 3,
		Daily: 4
	};

	var Models = {

		'user': {
			table: 'users',
			fetch_policy: Policy.Never
		},

		'globalUserState': {
			get: 'rest/globalUserStates',
			put: 'rest/globalUserStates',
			table: 'global_user_state',
			fetch_policy: Policy.Always
		},

		'activeSessions': {
			get: 'rest/activeClassSessions/:userId',
			table: 'active_lessons',
			fetch_policy: Policy.Always
		},

		'classStates': {
			get: 'rest/users/:userId/studyclassstates',
			put: 'rest/studyclassstatesList',
			table: 'class_states',
			fetch_policy: Policy.Always
		},

		'studentClassStates': {
			get: 'rest/schools/:schoolId/studyclasses/:classId/user/:userId/studentstudyclassstate',
			table: 'student_class_states',
			fetch_policy: Policy.Always
		},

		'userEventLogs': {
			table: 'user_event_logs',
			fetch_policy: Policy.Never
		},

		'userSequenceState': {
			get: 'rest/playerUserState/schoolId/:schoolId/userId/:userId/courseId/:courseId/lessonCid/:lessonCid/sequenceCid/:sequenceCid',
			get_list: 'rest/playerUserState/schoolId/:schoolId/userId/:userId/courseId/:courseId/lessonCid/:lessonCid',
			table: 'user_sequence_state',
			save_list: 'rest/playerStateList',
			fetch_policy: Policy.Always
		},

		'userAssessmentSequenceState': {
			get: 'rest/assessmentUserState/userId/:userId/assessmentInstanceId/:assessmentInstanceId/sequenceCid/:sequenceCid',
			table: 'assessment_sequence_state',
			save_list: 'rest/assessmentUserStateList',
			fetch_policy: Policy.Always
		},

		'userAssessmentSequenceScore': {
			table: 'assessment_sequence_score',
			fetch_policy: Policy.Never
		},

		'teacherAppletState': {
			table: 'teacher_applet_state',
			fetch_policy: Policy.Never
		},

		'course': {
			get: 'rest/userlibrary/courses/:courseId',
			table: 'course',
			fetch_policy: Policy.Daily
		},

		'lessonContent': {
			get: 'rest/userlibrary/courses/:courseId/lessons/:lessonCid',
			table: 'lesson_content',
			fetch_policy: Policy.Daily
		},

		'assessmentResult': {
			get: 'rest/assessmentStudyClassSession/assessmentInstanceId/:assessmentInstanceId',
			table: 'assessment_result',
			fetch_policy: Policy.Always
		},

		'assessment': {
			get: 'rest/userlibrary/courses/:courseId/assessments/:assessmentCid',
			table: 'assessment_content',
			fetch_policy: Policy.Daily
		},

		'classActivities': {
			get: 'rest/studentClassActivities/userId/:userId/schoolId/:schoolId/studyClassId/:classId',
			table: 'user_class_activities',
			fetch_policy: Policy.Always
		},

		'studyClasses': {
			get: 'rest/:role/:userId/studyclasses',
			table: 'study_classes',
			fetch_policy: Policy.Daily
		},

		'notes': {
			get: 'rest/userlibrary/courses/:courseId/lessons/:lessonCid/notes',
			table: 'lesson_notes',
			fetch_policy: Policy.Always
		},

		'appData': {
			get: 'rest/appdata',
			table: 'appdata',
			fetch_policy: Policy.Always
		},

		'loginData': {
			get: 'rest/loginInitData',
			table: 'logindata',
			fetch_policy: Policy.Always
		},

		'loginSessionData': {
			get: 'rest/loginSessionData',
			table: 'login_session_data',
			fetch_policy: Policy.Always
		},

		'standardPackages': {
			get: 'rest/standards/name/:name/subjectArea/:subjectArea/version/:version/',
			table: 'standard_packages',
			fetch_policy: Policy.Always
		},

		'lessonStatistics': {
			get: 'rest/rtcm/schools/:schoolId/studyClasses/:classId/sessionTimestamp/:timestamp/lessons/:lessonCid/courses/:courseId/lessonStatistics',
			table: 'lesson_statistics',
			fetch_policy: Policy.Always
		}
	};
	
	var DataManager = {

		sync: function() {
			var model = this._model,
				table = model.table,
				get = model.get,
				params = this._params,
				callback = this.callback || function(){},
				save = model.save,
				self = this;

			Logger.d('data-manager', 'start syncing data for model: $$', self.toString());
			Server.get(get, params, {
				success: function(res) {
					params.data = res;
					DB.save(table, params, {
						dirty: false,
						context: self,
						success: function() {
							Logger.d('data-manager', 'sync is successful for model: $$', self.toString());
							callback.apply(self);
						}
					});
				}
			});
		},

		flush: function(dataArray, paramsArray) {
			var model = this._model,
				table = model.table,
				save_list = model.save_list,
				get = model.get,
				callback = this.callback,
				self = this;

			Logger.d('data-manager', 'start flushing model $$ with data $$ to server.', self.toString(), dataArray);
			Server.saveInChunks(save_list, {data: dataArray}, {
				chunk_success: function(start, size, response) {
					Logger.d('data-manager', 'chunk server response: $$', response);
					for (var i = 0; (response && response.length && i < response.length); i++) {
						if (response[i].objectResult) {
							paramsArray[start + i].data.version = response[i].objectResult.version;
							DB.save(table, paramsArray[start + i], {dirty: false});
						} else if (response[i].error) {
							self.where(paramsArray[start + i]).sync();
						}
					}
					// last chunk
					if ((start + size) === paramsArray.length) {
						Logger.d('data-manager', 'save in chunks has ended successfuly.');
						callback.apply(self, [true]);
					}
				},
				success: function() {
					callback.apply(self, [false]);
				},
				error: function() {
					Logger.d('data-manager', "save in chunks respond with error.");
					callback.apply(self, [false]);
				},
				complete: function() {
					callback.apply(self, [true]);
				}
			});
		},

		getList: function() {
			var model = this._model,
				params = this._params,
				table = model.table,
				get = model.get,
				get_list = model.get_list,
				save = model.save,
				fetch_policy = model.fetch_policy || Policy.Always,
				self = this,
				callback = this.callback || function(){};

			Server.get(get_list, params, {
				success: function(res) {
					params.data = res;
					Logger.d('data-manager', 'data from server is fetched successfully for model: $$, data: $$', self.toString(), res);
					callback(res);
				},
				offline: function() {
					DB.get(table, params, {
						success: callback,
						context: self
					});
				}
			});
		},

		get: function() {
			var model = this._model,
				params = this._params,
				table = model.table,
				get = model.get,
				save = model.save,
				fetch_policy = model.fetch_policy || Policy.Always,
				self = this,
				callback = this.callback || function(){};
			Logger.d('data-manager', 'get model: $$', this.toString());

			switch (fetch_policy) {
				case Policy.Never:
					DB.get(table, params, {
						success: function(items) {
							var firstItem = (items && items.length) ? items[0] : { data: null, dirty: 0 };
							callback.apply(self, [firstItem.data, firstItem.dirty, firstItem]);
						}
					});
				break;
				case Policy.Always:
					DB.get(table, params, {
						success: function(items) {
							var firstItem = (items && items.length) ? items[0] : { data: null, dirty: 0 };
							if (firstItem.dirty) {
								Logger.d('data-manager', 'dirty data is founded for model: $$', self.toString());
								callback.apply(self, [firstItem.data, firstItem.dirty, firstItem]);
							} else {
								Logger.d('data-manager', 'data is not dirty or there is no data on local db, fetching data from server for model: $$', self.toString());
								Server.get(get, params, {
									success: function(res) {
										params.data = res;
										Logger.d('data-manager', 'data from server is fetched successfully for model: $$, data: $$', self.toString(), res);
										DB.save(table, params, {
											dirty: false,
											success: function(){
												callback.apply(self, [res]);
											}
										});
									},
									offline: function() {
										Logger.d('data-manager', 'server is offline, sending offline data for model: $$, data: $$', self.toString(), firstItem.data);
										callback.apply(self, [firstItem.data]);
									}
								});
							}
						}
					});
				break;
				case Policy.FirstTime:
					DB.get(table, params, {
						success: function(items) {
							var firstItem = (items && items.length) ? items[0] : { data: null, dirty: 0 };
							if (firstItem.data) {
								callback.apply(self, [firstItem.data, firstItem.dirty, firstItem]);
							} else {
								Server.get(get, params, {
									success: function(res) {
										params.data = res;
										Logger.d('data-manager', 'data from server is fetched successfully for model: $$, data: $$', self.toString(), res);
										DB.save(table, params, {
											dirty: false,
											success: function(){
												callback.apply(self, [res]);
											}
										});
									},
									offline: function() {
										Logger.d('data-manager', 'server is offline, sending offline data for model: $$, data: $$', self.toString(), firstItem.data);
										callback.apply(self, [firstItem.data]);
									}
								});
							}
						}
					});
				break;
				case Policy.Daily:
					DB.get(table, params, {
						success: function(items) {
							var nowtime = (new Date()).getTime(),
								firstItem = (items && items.length) ? items[0] : { data: null, dirty: 0, modified: 0},
								modified = (new Date(firstItem.modified)).getTime(),
								age = nowtime - modified;

							if ((firstItem.data) && (age <= 86400000)) {
								callback.apply(self, [firstItem.data, firstItem.dirty, firstItem]);
							} else {
								Server.get(get, params, {
									success: function(res) {
										params.data = res;
										Logger.d('data-manager', 'data from server is fetched successfully for model: $$, data: $$', self.toString(), res);
										DB.save(table, params, {
											dirty: false,
											success: function(){
												callback.apply(self, [res]);
											}
										});
									},
									offline: function() {
										Logger.d('data-manager', 'server is offline, sending offline data for model: $$, data: $$', self.toString(), firstItem.data);
										callback.apply(self, [firstItem.data]);
									}
								});
							}
						}
					});
				break;
			};
		},

		getLocal: function() {
			var model = this._model,
				params = this._params,
				table = model.table,
				self = this,
				callback = this.callback || function(){};
			params.dirty = 1;
			Logger.d('data-manager', 'get unsaved data for model: $$', this.toString());
			DB.get(table, params, {
				success: callback,
				context: self
			});
		},

		save: function() {
			var model = this._model,
				params = this._params,
				table = model.table,
				get = model.get,
				put = model.put,
				post = model.post,
				self = this,
				callback = this.callback || function(){};

			DB.save(table, params, {
				dirty: true,
				success: function() {
					if (post) {
						Server.post(post, params, {
							success: function(res) {
								Logger.d('data-manager', 'server is online, model $$ is sent to server.', self.toString());
								DB.save(table, params, {dirty: false});
								callback.apply(self, [res]);
							},
							offline: function() {
								Logger.d('data-manager', 'server is offline, model $$ is saved only on local db', self.toString());
								callback.apply(self, []);
							}
						});
					} else if (put) { 
						Server.put(put, params, {
							success: function(res) {
								Logger.d('data-manager', 'server is online, model $$ is sent to server.', self.toString());
								DB.save(table, params, {dirty: false});
								callback.apply(self, [res]);
							},
							offline: function() {
								Logger.d('data-manager', 'server is offline, model $$ is saved only on local db', self.toString());
								callback.apply(self, []);
							}
						});
					} else {
						callback.apply(self, []);
					}
				} 
			});
		},

		clear: function() {
			var model = this._model,
				params = this._params,
				table = model.table;
			Logger.d('data-manager', 'delete model $$ from db.', this.toString());
			DB.clear(table, params);
		}
	};

	/*
	* Model class
	*/
	var Model = function(name) {
		this._name = name;
		this._model = Models[name];
		this._params = {};
	};

	Model.prototype.toString = function() {
		return this._name + ": " + JSON.stringify(this._params);
	};

	Model.prototype.where = function(params) {
		this._params = params;
		return this;
	};

	Model.prototype.save = function(callback) {
		this.callback = callback;
		return DataManager.save.apply(this);
	};

	Model.prototype.get = function(callback) {
		this.callback = callback;
		return DataManager.get.apply(this);
	};

	Model.prototype.getList = function(callback) {
		this.callback = callback;
		return DataManager.getList.apply(this);
	};

	Model.prototype.clear = function() {
		return DataManager.clear.apply(this);
	};

	Model.prototype.getLocal = function(callback) {
		this.callback = callback;
		return DataManager.getLocal.apply(this);
	};

	Model.prototype.flush = function(dataArray, paramsArray, callback) {
		this.callback = callback;
		return DataManager.flush.apply(this, [dataArray, paramsArray]);
	};

	Model.prototype.sync = function(callback) {
		this.callback = callback;
		return DataManager.sync.apply(this);
	};

	/*
	* Model Factory
	*/
	return function(name){
		return new Model(name);
	};
});