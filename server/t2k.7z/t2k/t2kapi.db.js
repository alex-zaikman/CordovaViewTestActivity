/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* DB Manager
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(['./t2kapi.logger'],
function(Logger) {

	var _db_handler = null;

	var DB_SIZE = 25 * 1024 * 1024;

	var Error = {
		DatabaseClosed: 'DatabaseClosed',
		NotEnoughSpace: 'NotEnoughSpace',
		NotSuchTable: 'NotSuchTable',
		Unknown: 'Unknown'
	};

	var init = function() {
		_db_handler = openDatabase('t2kapi-db', '1.0', 't2k api db', DB_SIZE);
	};

	var db_error = function(err) {
		if (typeof(err) === 'object') {
			switch (err.code) {
				case 0:
					return Error.DatabaseClosed;
				case 4:
					return Error.NotEnoughSpace;
				case 5:
					return Error.NotSuchTable;
			}
		} else {
			return Error.Unknown;
		}
	};

	var select = function(query, success, error) {
		error = error || function(){};
		Logger.d('db', 'start executing query: $$', query);
		_db_handler.transaction(function(tx) {
			tx.executeSql(query, [], function(tx, results) {
				var items = [];
				for (var i = 0; i < results.rows.length; i++) {
					items[i] = {};
					for (var key in results.rows.item(i)) {
						items[i][key] = decodeData(results.rows.item(i)[key]);
					}
				}
				success(items);
			});
		}, function(err){
			Logger.d('db', 'query error $$, $$',query, err);
			if (db_error(err) === Error.DatabaseClosed) {
				init();
				select(query, success, error);
			} else {
				success.apply(this, []);	
			}
		});
	};

	var update = function(queryArray, success, error) {
		var error = error || function(){};
		Logger.d('db', 'open new transaction to update data');
		if (queryArray.length === 0) {
			success();
			return;
		}
		_db_handler.transaction(function(tx) {
			for (var i = 0; i < queryArray.length; i++) {
				Logger.d('db', 'run query: ' + queryArray[i]);
				if (i === (queryArray.length - 1)) {
					tx.executeSql(queryArray[i], [], success);
				} else {
					tx.executeSql(queryArray[i], [], function(){});
				}
			}
		}, function(err) {
			Logger.e('db', 'update process error: $$', err);
			if (db_error(err) === Error.NotEnoughSpace) {
				Logger.e('db', 'not enough space on t2kdb');
				success();
			} else if (db_error(err) === Error.DatabaseClosed) {
				init();
				update(queryArray, success, error);
			}
		});
	};

	var getTableFields = function(params, withPrimaryKey) {
		var tableFields = [];
		var primaryKeyArray = [];
		for (var column in params) {
			if ((column === 'dirty') || (column === "modified")) {
				continue;
			}
			tableFields.push(column);
			if (column !== 'data') {
				primaryKeyArray.push(column);
			}
		}
		tableFields.push('dirty');
		tableFields.push('modified');
		if (withPrimaryKey) {
			tableFields.push('PRIMARY KEY ('+primaryKeyArray.join(',')+')');
		}
		return tableFields;
	};

	var getTableValues = function(params, dirty) {
		var values = [];
		for (var column in params) {
			var val = params[column];
			if ((column === 'dirty') || (column === "modified")) {
				continue;
			}
			switch (typeof(val)) {
				case 'number':
					values.push(val);
				break;
				case 'object':
					values.push('"'+encodeData(val)+'"')
				break;
				default:
					values.push('"'+val+'"');
				break;
			}
		}
		values.push((dirty) ? 1 : 0);
		values.push('"' + new Date() + '"');
		return values;
	};

	var getTableSearch = function(params, except) {
		var conditions = [];
		for (var column in params) {
			if (column === 'data') {
				continue;
			}
			var val = params[column];
			if (typeof(val) === 'number') {
				val = val;
				conditions.push(column + ' = ' + val);
			} else if (Array.isArray(val) && val.length) {
				var tempVal = val.slice(0);
				if (typeof(tempVal[0]) !== 'number') {
					for (var i = 0; i < tempVal.length; i++) {
						tempVal[i] = '"' + tempVal[i] + '"';
					}
				}
				conditions.push(column + ' in ' + '(' + tempVal.join(",") + ')');
			} else {
				val = '"'+val+'"';
				conditions.push(column + ' = ' + val);
			}
		}
		for (var column in except) {
			if (column === 'data') {
				continue;
			}
			var val = except[column];
			if (typeof(val) === 'number') {
				val = val;
				conditions.push(column + ' != ' + val);
			} else if (Array.isArray(val) && val.length) {
				var tempVal = val.slice(0);
				if (typeof(tempVal[0]) !== 'number') {
					for (var i = 0; i < tempVal.length; i++) {
						tempVal[i] = '"' + tempVal[i] + '"';
					}
				}
				conditions.push(column + ' not in ' + '(' + tempVal.join(",") + ')');
			} else {
				val = '"'+val+'"';
				conditions.push(column + ' != ' + val);
			}
		}
		return conditions;
	};

	var encodeData = function(data) {
		var dataStr;
		if (typeof(data) === 'undefined') {
			return data;
		}
		try {
			dataStr = JSON.stringify(data);
		} catch (e) {
			dataStr = data;
		} finally {
			return dataStr.replace(/"/g, '&quot;');
		}
	};

	var decodeData = function(data) {
		if (typeof(data) === 'undefined') {
			return data;
		}
		var dataObj;
		try {
			data = data.replace(/&quot;/g, '"');
			dataObj = JSON.parse(data);
		} catch (e) {
			dataObj = data;
		} finally {
			return dataObj;
		}
	};

	var getCreateSQLTableQuery = function(table, params, dirty) {
		return 'CREATE TABLE IF NOT EXISTS ' + table + ' ('+getTableFields(params, true).join(',') +')';
	};

	var getInsertSQLTableQuery = function(table, params, dirty) {
		return 'INSERT OR REPLACE INTO ' + table + '(' + getTableFields(params, false).join(',') + ') VALUES ('+getTableValues(params, dirty).join(',')+')';
	};

	return {

		init: init,

		save: function(table, params, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){},
				context = options.context || this,
				dirty = options.dirty;

			if (table) {
				var createString = getCreateSQLTableQuery(table, params, dirty),
					insertString = getInsertSQLTableQuery(table, params, dirty);
				update([createString, insertString], success, error);
			} else {
				success();
			}
		},

		saveList: function(table, params, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){},
				context = options.context || this,
				dirty = options.dirty,
				key = options.key || 'id',
				itemParams = $.extend({}, params),
				queriesArray = [];

			if (table) {
				for (var i = 0; (params.data) && (i < params.data.length); i++) {
					itemParams.data = params.data[i];
					itemParams[key] = params.data[i][key];
					if (i === 0) {
						queriesArray.push(getCreateSQLTableQuery(table, itemParams, dirty));
					}
					queriesArray.push(getInsertSQLTableQuery(table, itemParams, dirty));
				}
				update(queriesArray, success, error);
			} else {
				success();
			}
		},

		get: function(table, params, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){},
				context = options.context || this,
				except = options.except || {},
				conditions = getTableSearch(params, except);

			if (table) {
				var selectString = (conditions.length) ? 'SELECT * FROM ' + table + ' WHERE ' + conditions.join(' and ') : 'SELECT * FROM ' + table;
				select(selectString, function(items){
					success.apply(context, [items]);
				}, function(e){
					Logger.e('db', 'failed to get params $$, except $$ with error $$',params, except, e);
					error.apply(context, [e]);
				});
			} else {
				success.apply(context, []);
			}
		},

		clear: function(table, params, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){},
				except = options.except || {},
				conditions = getTableSearch(params, except),
				context = options.context || this,
				selectString = (conditions.length) ? 'DELETE FROM ' + table + ' WHERE ' + conditions.join(' and ') : 'DELETE FROM ' + table;
			if (table) {
				Logger.d('db', 'clearing table: $$ where: $$, except: $$', table, params, except);
				select(selectString, function(){
					Logger.d('db', 'clear $$ where $$ except $$ successfull', table, params, except);
					success.apply(context, []);
				},function(e){
					Logger.e('db', 'clear $$ where $$, except $$ is failed', table, params, except);
					error.apply(context, [e]);
				});
			} else {
				success.apply(context, []);
			}
		},

		select: function(query, options) {
			var options = options || {},
				success = options.success || function(){},
				error = options.error || function(){};
			select(query, success, error);
		},

		getHandler: function() {
			return _db_handler;
		}
	};
	return DB;
});
