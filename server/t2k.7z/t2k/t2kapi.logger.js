/*----------------------------------------------------------------------------
* T2K Middleware Javascript API
* Logger
* Author: Elad Yarkoni
*
*
*
*----------------------------------------------------------------------------*/
define(function() {

	var print = function(type, args) {
		var val;
		var objectsToPrint = [];
		for (var i = 2; i < args.length; i++) {
			if (typeof(args[i]) === 'object') {
				objectsToPrint.push(args[i]);
			}
			val = args[i];
			args[1] = args[1].replace('$$', val);
		}
		//console.log('T2KAPI MESSAGE: ['+type+'] ['+args[0].toUpperCase()+']: ' + args[1]);
		//console.log(objectsToPrint);
	};

	return {

		d: function(module, messageFormat) {
			print('DEBUG', arguments);
		},

		e: function(module, message) {
			print('ERROR', arguments);
		},

		w: function() {
			print('WARN', arguments);
		}
	};
});